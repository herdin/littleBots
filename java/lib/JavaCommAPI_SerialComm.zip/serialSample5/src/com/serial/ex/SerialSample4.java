package com.serial.ex;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.comm.CommPort;
import javax.comm.CommPortIdentifier;
import javax.comm.SerialPort;
import javax.swing.BorderFactory;
import javax.swing.ComboBoxModel;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.BevelBorder;

import com.cloudgarden.layout.AnchorConstraint;
import com.cloudgarden.layout.AnchorLayout;

/**
* This code was edited or generated using CloudGarden's Jigloo
* SWT/Swing GUI Builder, which is free for non-commercial
* use. If Jigloo is being used commercially (ie, by a corporation,
* company or business for any purpose whatever) then you
* should purchase a license for each developer using Jigloo.
* Please visit www.cloudgarden.com for details.
* Use of Jigloo implies acceptance of these licensing terms.
* A COMMERCIAL LICENSE HAS NOT BEEN PURCHASED FOR
* THIS MACHINE, SO JIGLOO OR THIS CODE CANNOT BE USED
* LEGALLY FOR ANY CORPORATE OR COMMERCIAL PURPOSE.
*/
public class SerialSample4 extends javax.swing.JFrame {

	private JMenuItem helpMenuItem;
	private JMenu jMenu5;
	private JLabel jLabel2;
	private JLabel jLabel1;
	private JComboBox jComboBox_stopbit;
	private JComboBox jComboBox_ptybit;
	private JComboBox jComboBox_databit;
	private JComboBox jComboBox_baud;
	private JTextField jTextField_sendData;
	private JTextField jTextField_status;
	private JButton jButton_sendData;
	private JButton jButton1;
	private JLabel jLabel8;
	static JTextArea jTextArea_receivedData;
	private JLabel jLabel7;
	private JSeparator jSeparator4;
	private JButton jButton_close;
	private JButton jButton_open;
	private JLabel jLabel6;
	private JLabel jLabel5;
	private JLabel jLabel4;
	private JLabel jLabel3;
	private JComboBox jComboBox_port;
	private JMenuItem deleteMenuItem;
	private JSeparator jSeparator1;
	private JMenuItem pasteMenuItem;
	private JMenuItem copyMenuItem;
	private JMenuItem cutMenuItem;
	private JMenu jMenu4;
	private JMenuItem exitMenuItem;
	private JSeparator jSeparator2;
	private JMenuItem closeFileMenuItem;
	private JMenuItem saveAsMenuItem;
	private JMenuItem saveMenuItem;
	private JMenuItem openFileMenuItem;
	private JMenuItem newFileMenuItem;
	private JMenu jMenu3;
	private JMenuBar jMenuBar1;
	
	static Thread receiveThread;
	static InputStream iStream;	
	static boolean connStatus;
	static OutputStream oStream;	
	static CommPort cPort;
	static SerialPort sPort;	

	/**
	* Auto-generated main method to display this JFrame
	*/
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				SerialSample4 inst = new SerialSample4();
				inst.setLocationRelativeTo(null);
				inst.setVisible(true);
			}
		});
	}
	
	public SerialSample4() {
		super();
		initGUI();
	}
	
	private void initGUI() {
		try {
			AnchorLayout thisLayout = new AnchorLayout();
			getContentPane().setLayout(thisLayout);
			{
				jTextField_status = new JTextField();
				getContentPane().add(jTextField_status, new AnchorConstraint(28, 247, 266, 54, AnchorConstraint.ANCHOR_ABS, AnchorConstraint.ANCHOR_ABS, AnchorConstraint.ANCHOR_ABS, AnchorConstraint.ANCHOR_ABS));
				jTextField_status.setPreferredSize(new java.awt.Dimension(215, 30));
			}
			{
				jButton_sendData = new JButton();
				getContentPane().add(jButton_sendData, new AnchorConstraint(692, 721, 766, 605, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jButton_sendData.setText("\uc804\uc1a1");
				jButton_sendData.setPreferredSize(new java.awt.Dimension(60, 24));
				jButton_sendData.addMouseListener(new MouseAdapter() {
					public void mouseClicked(MouseEvent evt) {
						jButton_sendDataMouseClicked(evt);
					}
				});
			}
			{
				jButton1 = new JButton();
				getContentPane().add(jButton1, new AnchorConstraint(831, 684, 905, 409, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jButton1.setText("\ud504\ub85c\uadf8\ub7a8 \uc885\ub8cc");
				jButton1.setPreferredSize(new java.awt.Dimension(129, 24));
				jButton1.addMouseListener(new MouseAdapter() {
					public void mouseClicked(MouseEvent evt) {
						jButton1MouseClicked(evt);
					}
				});
			}
			{
				jTextField_sendData = new JTextField();
				getContentPane().add(jTextField_sendData, new AnchorConstraint(603, 966, 677, 605, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jTextField_sendData.setPreferredSize(new java.awt.Dimension(186, 24));
				jTextField_sendData.setEditable(false);
				jTextField_sendData.setBorder(BorderFactory.createEtchedBorder(BevelBorder.LOWERED));
			}
			{
				jLabel8 = new JLabel();
				getContentPane().add(jLabel8, new AnchorConstraint(532, 803, 584, 605, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jLabel8.setText("\uc1a1\uc2e0 \ub370\uc774\ud130 :");
				jLabel8.setPreferredSize(new java.awt.Dimension(102, 17));
			}
			{
				jTextArea_receivedData = new JTextArea();
				getContentPane().add(jTextArea_receivedData, new AnchorConstraint(245, 966, 424, 605, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jTextArea_receivedData.setPreferredSize(new java.awt.Dimension(186, 58));
				jTextArea_receivedData.setCaretColor(new java.awt.Color(128,128,255));
				jTextArea_receivedData.setBorder(BorderFactory.createEtchedBorder(BevelBorder.LOWERED));
				jTextArea_receivedData.setEditable(false);
			}
			{
				jLabel7 = new JLabel();
				getContentPane().add(jLabel7, new AnchorConstraint(168, 818, 220, 597, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jLabel7.setText("\uc218\uc2e0 \ub370\uc774\ud130 :");
				jLabel7.setPreferredSize(new java.awt.Dimension(114, 17));
			}
			{
				jSeparator4 = new JSeparator();
				getContentPane().add(jSeparator4, new AnchorConstraint(100, 582, 782, 572, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jSeparator4.setPreferredSize(new java.awt.Dimension(5, 221));
				jSeparator4.setOrientation(SwingConstants.VERTICAL);
			}
			{
				jButton_close = new JButton();
				getContentPane().add(jButton_close, new AnchorConstraint(692, 458, 763, 255, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jButton_close.setText("\uc5f0\uacb0 \uc885\ub8cc");
				jButton_close.setPreferredSize(new java.awt.Dimension(95, 23));
				jButton_close.addMouseListener(new MouseAdapter() {
					public void mouseClicked(MouseEvent evt) {
						jButton_closeMouseClicked(evt);
					}
				});
			}
			{
				jButton_open = new JButton();
				getContentPane().add(jButton_open, new AnchorConstraint(692, 229, 763, 33, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jButton_open.setText("\ud3ec\ud2b8 \uc5f0\uacb0");
				jButton_open.setPreferredSize(new java.awt.Dimension(92, 23));
				jButton_open.addMouseListener(new MouseAdapter() {
					public void mouseClicked(MouseEvent evt) {
						jButton_openMouseClicked(evt);
					}
				});
			}
			{
				jLabel6 = new JLabel();
				getContentPane().add(jLabel6, new AnchorConstraint(87, 111, 146, 20, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jLabel6.setText("Status :");
				jLabel6.setPreferredSize(new java.awt.Dimension(47, 19));
			}
			{
				jLabel5 = new JLabel();
				getContentPane().add(jLabel5, new AnchorConstraint(563, 227, 628, 72, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jLabel5.setText("Stop Bits :");
				jLabel5.setPreferredSize(new java.awt.Dimension(80, 21));
			}
			{
				jLabel4 = new JLabel();
				getContentPane().add(jLabel4, new AnchorConstraint(470, 231, 535, 76, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jLabel4.setText("Parity Bits :");
				jLabel4.setPreferredSize(new java.awt.Dimension(80, 21));
			}
			{
				jLabel3 = new JLabel();
				getContentPane().add(jLabel3, new AnchorConstraint(381, 231, 445, 76, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jLabel3.setText("Data Bits :");
				jLabel3.setPreferredSize(new java.awt.Dimension(80, 21));
			}
			{
				jLabel2 = new JLabel();
				getContentPane().add(jLabel2, new AnchorConstraint(297, 231, 362, 76, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jLabel2.setText("Baud rate :");
				jLabel2.setPreferredSize(new java.awt.Dimension(80, 21));
			}
			{
				jLabel1 = new JLabel();
				getContentPane().add(jLabel1, new AnchorConstraint(217, 231, 282, 76, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jLabel1.setText("COM Port :");
				jLabel1.setPreferredSize(new java.awt.Dimension(80, 21));
			}
			{
				ComboBoxModel jComboBox_stopbitModel = 
					new DefaultComboBoxModel(
							new String[] { "1", "1.5", "2" });
				jComboBox_stopbit = new JComboBox();
				getContentPane().add(jComboBox_stopbit, new AnchorConstraint(560, 409, 625, 254, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jComboBox_stopbit.setModel(jComboBox_stopbitModel);
				jComboBox_stopbit.setPreferredSize(new java.awt.Dimension(80, 21));
			}
			{
				ComboBoxModel jComboBox_ptybitModel = 
					new DefaultComboBoxModel(
							new String[] { "NONE", "EVEN", "ODD" });
				jComboBox_ptybit = new JComboBox();
				getContentPane().add(jComboBox_ptybit, new AnchorConstraint(473, 409, 538, 254, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jComboBox_ptybit.setModel(jComboBox_ptybitModel);
				jComboBox_ptybit.setPreferredSize(new java.awt.Dimension(80, 21));
			}
			{
				ComboBoxModel jComboBox_databitModel = 
					new DefaultComboBoxModel(
							new String[] { "8", "7", "6", "5", "4" });
				jComboBox_databit = new JComboBox();
				getContentPane().add(jComboBox_databit, new AnchorConstraint(387, 409, 452, 254, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jComboBox_databit.setModel(jComboBox_databitModel);
				jComboBox_databit.setPreferredSize(new java.awt.Dimension(80, 21));
			}
			{
				ComboBoxModel jComboBox_baudModel = 
					new DefaultComboBoxModel(
							new String[] { "9600", "14400", "19200", "38400", "56000" });
				jComboBox_baud = new JComboBox();
				getContentPane().add(jComboBox_baud, new AnchorConstraint(300, 409, 365, 254, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jComboBox_baud.setModel(jComboBox_baudModel);
				jComboBox_baud.setPreferredSize(new java.awt.Dimension(80, 21));
			}
			{
				ComboBoxModel jComboBox_portModel = 
					new DefaultComboBoxModel(
							new String[] { "COM1", "COM2", "COM3", "COM4" });
				jComboBox_port = new JComboBox();
				getContentPane().add(jComboBox_port, new AnchorConstraint(214, 409, 279, 254, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL, AnchorConstraint.ANCHOR_REL));
				jComboBox_port.setModel(jComboBox_portModel);
				jComboBox_port.setPreferredSize(new java.awt.Dimension(80, 21));
			}
			this.setSize(532, 389);
			{
				jMenuBar1 = new JMenuBar();
				setJMenuBar(jMenuBar1);
				{
					jMenu3 = new JMenu();
					jMenuBar1.add(jMenu3);
					jMenu3.setText("File");
					{
						newFileMenuItem = new JMenuItem();
						jMenu3.add(newFileMenuItem);
						newFileMenuItem.setText("New");
					}
					{
						openFileMenuItem = new JMenuItem();
						jMenu3.add(openFileMenuItem);
						openFileMenuItem.setText("Open");
					}
					{
						saveMenuItem = new JMenuItem();
						jMenu3.add(saveMenuItem);
						saveMenuItem.setText("Save");
					}
					{
						saveAsMenuItem = new JMenuItem();
						jMenu3.add(saveAsMenuItem);
						saveAsMenuItem.setText("Save As ...");
					}
					{
						closeFileMenuItem = new JMenuItem();
						jMenu3.add(closeFileMenuItem);
						closeFileMenuItem.setText("Close");
					}
					{
						jSeparator2 = new JSeparator();
						jMenu3.add(jSeparator2);
					}
					{
						exitMenuItem = new JMenuItem();
						jMenu3.add(exitMenuItem);
						exitMenuItem.setText("Exit");
					}
				}
				{
					jMenu4 = new JMenu();
					jMenuBar1.add(jMenu4);
					jMenu4.setText("Edit");
					{
						cutMenuItem = new JMenuItem();
						jMenu4.add(cutMenuItem);
						cutMenuItem.setText("Cut");
					}
					{
						copyMenuItem = new JMenuItem();
						jMenu4.add(copyMenuItem);
						copyMenuItem.setText("Copy");
					}
					{
						pasteMenuItem = new JMenuItem();
						jMenu4.add(pasteMenuItem);
						pasteMenuItem.setText("Paste");
					}
					{
						jSeparator1 = new JSeparator();
						jMenu4.add(jSeparator1);
					}
					{
						deleteMenuItem = new JMenuItem();
						jMenu4.add(deleteMenuItem);
						deleteMenuItem.setText("Delete");
					}
				}
				{
					jMenu5 = new JMenu();
					jMenuBar1.add(jMenu5);
					jMenu5.setText("Help");
					{
						helpMenuItem = new JMenuItem();
						jMenu5.add(helpMenuItem);
						helpMenuItem.setText("Help");
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean rs232Connect(String portName, String baud, String dBit, String pBit, String sBit){

		int baudrate;
		int databits;
		int paritybit;
		int stopbit;
		
		try{
		   //��Ʈ �ĺ��� ��ü ȹ�� �� ��Ʈ ��ü ����
  		   CommPortIdentifier p = CommPortIdentifier.getPortIdentifier(portName);
		
		   //���� open �Ǿ� ���� ���� ��� open
		   if(p.isCurrentlyOwned()){   //���� open �Ǿ� ������
			   System.out.println("Error : Port is currently in use");
			   return false;
		   }else{                      //���� open �Ǿ� ���� ������ ����
			   cPort = p.open(this.getClass().getName(), 2000);
			   System.out.println(portName+" port opened.....");
			   sPort = (SerialPort) cPort;
			   
			   baudrate = Integer.parseInt(baud);
			   databits = Integer.parseInt(dBit);
			   paritybit = sPort.PARITY_NONE;
			   stopbit = Integer.parseInt(sBit);
				
			   sPort.setSerialPortParams(baudrate, databits, stopbit, paritybit);			   
			
			   //��Ʈ����ü ����
			   iStream = sPort.getInputStream();
			   oStream = sPort.getOutputStream();
			   System.out.println("i/o stream object created.....");
				
			   return true;
		   }
	    }catch(Exception e){
	    	System.out.println(e);
	    	return false;
	    }
	}	
	
	private void jButton_openMouseClicked(MouseEvent evt) {
		System.out.println("jButton_open.mouseClicked, event="+evt);
		//TODO add your code for jButton_open.mouseClicked
		
		jTextField_status.setText("Please wait a moment.");   
		System.out.println("Please wait a moment.");  
		
		//�޺� �ڽ��� �� �о��
		String port = (String) jComboBox_port.getSelectedItem();
		String baud = (String) jComboBox_baud.getSelectedItem();
		String databit = (String) jComboBox_databit.getSelectedItem();
		String ptybit = (String) jComboBox_ptybit.getSelectedItem();
		String stopbit = (String) jComboBox_stopbit.getSelectedItem();		 
		
		//��Ʈ ����
    	try{		
    		connStatus = this.rs232Connect(port,baud,databit,ptybit,stopbit);
    		
    		//��Ʈ ���⿡ ���� ��� ���
    		if(connStatus){
    			jTextField_status.setText(port+ " : opened... [O.K] , " + baud+"[bps]");

			    //Thread ����(����, �۽� ����)
	    	    Runnable receiveJob = new SerialReader(iStream, jTextArea_receivedData);
	            receiveThread =  new Thread(receiveJob);	            
	            receiveThread.start();
				System.out.println("receive Thread Started....");
				jTextField_sendData.setEditable(true);
				jTextArea_receivedData.setEditable(true);				
    		}else{
    			jTextField_status.setText("Can't open "+port+" Port");
    		}
    	}catch(Exception e){
    		e.printStackTrace();
    	}		
	}
	
	private void jButton_closeMouseClicked(MouseEvent evt) {
		System.out.println("jButton_close.mouseClicked, event="+evt);
		//TODO add your code for jButton_close.mouseClicked
	    closePort();
	    jTextField_status.setText("Connection Closed... OK");	
		jTextField_sendData.setEditable(false);	    
		jTextArea_receivedData.setEditable(false);			
	}
	
	private void jButton1MouseClicked(MouseEvent evt) {
		System.out.println("jButton1.mouseClicked, event="+evt);
		//TODO add your code for jButton1.mouseClicked
        closePort();
        System.exit(1);
	}

	private void closePort(){
		if(connStatus) receiveThread.stop();
		if (sPort != null) {  
           try {  
               // close the i/o streams.  
               oStream.close();  
               iStream.close();  
           } catch (IOException ex) {
        	   ex.printStackTrace();
           }  
           sPort.close();
       }
	}
	
	private void jButton_sendDataMouseClicked(MouseEvent evt) {
		System.out.println("jButton_sendData.mouseClicked, event="+evt);
		//TODO add your code for jButton_sendData.mouseClicked
		String command = jTextField_sendData.getText();
		byte[] sendData = command.getBytes();
		try{
		   if(sendData[0] == 's'){
		        closePort();
		        System.exit(1);
		    }else{			
		       oStream.write(sendData[0]);
		    }
		}catch(IOException e){
			System.out.println("������ ���� ����");				
			e.printStackTrace();
		}		
	}
}
