import java.awt.*;
import java.awt.event.*;
 
public class AlertDialog extends Dialog implements ActionListener {
    public AlertDialog(Frame parent, 
		       String title, 
		       String lineOne, 
		       String lineTwo,
		       String lineThree) {
	super(parent, title, true);

	Panel labelPanel = new Panel();
	labelPanel.setLayout(new GridLayout(3, 1));
	labelPanel.add(new Label(lineOne, Label.CENTER));
	labelPanel.add(new Label(lineTwo, Label.CENTER));
	labelPanel.add(new Label(lineThree, Label.CENTER));
	add(labelPanel, "Center");

	Panel buttonPanel = new Panel();
	Button okButton = new Button("OK");
	okButton.addActionListener(this);
	buttonPanel.add(okButton);
	add(buttonPanel, "South");

	FontMetrics fm = getFontMetrics(getFont());
	int width = Math.max(fm.stringWidth(lineOne), 
		 Math.max(fm.stringWidth(lineTwo), fm.stringWidth(lineThree)));

	setSize(width + 40, 150);
	setLocation(parent.getLocationOnScreen().x + 30, 
		    parent.getLocationOnScreen().y + 30);
	setVisible(true);
    }
    public void actionPerformed(ActionEvent e) {
	setVisible(false);
	dispose();
    }
}
